TAROT SMP ELECTION — SETUP

1. Upload/replace index.html in your GitHub Tarot-SMP repository.
2. This website needs a shared database because GitHub Pages alone cannot save votes for everyone.
3. Create a Google Sheet -> Extensions -> Apps Script -> paste Code.gs.
4. Deploy as Web app, Execute as Me, access Anyone. Copy the Web App URL.
5. In index.html replace PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE with that URL.
6. Change REVEAL_AT to your exact India date/time.
7. Change CANDIDATES to your exact candidate names.
8. Commit the updated index.html to GitHub Pages.

After a vote is submitted the site shows:
"Vote Submitted Successfully"
"Results will be revealed at: ..."
plus a live countdown.
After the reveal time, the same site shows the winner and each candidate's vote count.

Important: one-vote-per-name is not a secure identity system; someone could type another person's name. It is suitable for a private SMP-style election, not real-world elections.
